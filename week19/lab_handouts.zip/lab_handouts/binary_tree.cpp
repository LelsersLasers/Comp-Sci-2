#include<string>
#include "binary_tree.h"

Tree::Tree() {

}

void Tree::add_node(long content) {

}